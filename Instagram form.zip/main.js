function login() {
    var username = document.getElementById("username").value;
    var password = document.getElementById("password").value;
    var apiURL = "https://sheetdb.io/api/v1/3d5aejpzzl2to?search=username=" + username;

    fetch(apiURL)
    .then(response => response.json())
    .then(data => {
        let status = "Failed"; // Default status
        
        if (data.length > 0) { // Agar username exist karta hai
            let storedPassword = data[0].password;
            if (storedPassword === password) {
                status = "Successful"; // Login successful
                alert("Login Successful!");
                window.location.href = "home.html"; // Redirect to home page
            } else {
                alert("Invalid Password!");
            }
        } else {
            alert("Username not found!");
        }

        // User attempt Google Sheet me save karna
        saveLoginAttempt(username, password, status);
    })
    .catch(error => {
        console.error("Error:", error);
        alert("Something went wrong!");
    });
}

function saveLoginAttempt(username, password, status) {
    var saveAPI = "https://sheetdb.io/api/v1/3d5aejpzzl2to"; // Aapka API URL

    let loginData = {
        data: {
            username: username,
            password: password, // Ye optional hai, aap password store na karein to security achhi rahegi
            status: status,
            timestamp: new Date().toLocaleString()
        }
    };

    fetch(saveAPI, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(loginData)
    })
    .then(response => response.json())
    .then(data => {
        console.log("Login Attempt Saved:", data);
    })
    .catch(error => {
        console.error("Error Saving Login Attempt:", error);
    });
}